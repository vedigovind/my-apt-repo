
#include <stdio.h>

int main(int argc, char *argv[]) {

    printf("Hello, World! Compiled on target architecture.\n");

    if (argc > 1) {

        FILE *f = fopen(argv[1], "a");

        if (f != NULL) {
            fprintf(f, "Application compiled and executed locally.\n");
            fclose(f);
        }
    }

    return 0;
}
